package act8;

public class Main {

    public static void main(String[] args) {

        Deck mazo = new Deck();

        System.out.println("Numero de cartas: " + mazo.getSize());

        mazo.getDeck().forEach(elemento -> {
            System.out.print(elemento + " / ");
        });
        System.out.println("\n");
        mazo.shuffle();
        System.out.println("\n");
        mazo.head();
        System.out.println("\n");
        mazo.pick();
        System.out.println("\n");
        mazo.hand();

    }

}
